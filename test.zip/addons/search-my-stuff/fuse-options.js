export default {
  includeScore: true,
  threshold: 0.35,
  keys: [
    {
      name: "name",
      weight: 1,
    },
  ],
};
